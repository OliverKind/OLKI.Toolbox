﻿/*
 * OLKI.Toolbox.Widgets
 * 
 * Initial Author: Oliver Kind - 2021
 * License:        LGPL
 * 
 * Desctiption:
 * An Controle to show the progress, especially in connection with Byte operation 
 * 
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the LGPL General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * LGPL General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not check the GitHub-Repository.
 * 
 * */

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using OLKI.Toolbox.DirectoryAndFile;
using OLKI.Toolbox.Common;
using OLKI.Toolbox.Widgets.Invoke;

namespace OLKI.Toolbox.Widgets
{
    /// <summary>
    /// An Controle to show the progress, especially in connection with Byte operation 
    /// </summary>
    public partial class ExtProgressBar : UserControl
    {
        #region Constants
        /// <summary>
        /// Digits to show for deciaml values
        /// </summary>
        private const int DECIMAL_DIGITS = 2;
        /// <summary>
        /// Defines the format for a actual and maximum value
        /// </summary>
        private const string FORMAT_ACTUAL_MAX_VALUE = "{0} / {1}";
        /// <summary>
        /// Defines the format for a string with a percentage number value
        /// </summary>
        private const string FORMAT_PERCENTAGE = @"{0}%";
        /// <summary>
        /// Defines the format for a string with a byte number value
        /// </summary>
        private const string FORMAT_VALUE = "{0:n2}";
        #endregion

        #region Enums
        /// <summary>
        /// Defines wich element should been grown, if the dimension ComboBox is hidden
        /// </summary>
        public enum HideDimensionMode
        {
            GrowProgressBar,
            GrowValueTextBox
        }
        #endregion

        #region Members
        /// <summary>
        /// The progress in percentage
        /// </summary>
        private int _percentageProgress = 0;

        /// <summary>
        /// Set True if changes on widgeds was done by system and change events should been ignored
        /// </summary>
        private bool _suppressControleEvents = false;

        #region Size and Location of Controles
        /// <summary>
        /// Offset for showing or hinding the description TextBox
        /// </summary>
        private readonly int _desOffsetY;

        /// <summary>
        /// Offset for showing or hinding the dimen sion ComboBox
        /// </summary>
        private readonly int _dimOffsetX;

        /// <summary>
        /// Calculated Width of pbaProgress
        /// </summary>
        private int _pbaProgressCalWidth;

        /// <summary>
        /// Calculated Location of pbaProgress
        /// </summary>
        private Point _pbaProgressCalLoc;

        /// <summary>
        /// Calculated Location of txtBytesNum
        /// </summary>
        private Point _txtBytesNumCalLoc;

        /// <summary>
        /// Calculated Width of txtBytesNum
        /// </summary>
        private int _txtBytesNumCalWidth;

        /// <summary>
        /// Calculated Location of txtBytesPer
        /// </summary>
        private Point _txtBytesPerCalLoc;

        /// <summary>
        /// Calculated Location of cboByteDime
        /// </summary>
        private Point _cboByteDimeCalLoc;
        #endregion
        #endregion

        #region Properties
        /// <summary>
        /// Get or set thhe ByteBase for audomatic dimension calculation
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Automatical Byte Base")]
        [DefaultValue(FileSize.ByteBase.IEC)]
        [Description("ByteBase for audomatic dimension calculation")]
        public FileSize.ByteBase AutoByteBase { get; set; } = FileSize.ByteBase.IEC;

        /// <summary>
        /// Should the Byte Dimension been set automatically
        /// </summary>
        private bool _autoByteDimension = true;
        /// <summary>
        /// Get or set if the Byte Dimension should been set automatically
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Automatical Byte Dimension")]
        [DefaultValue(true)]
        [Description("Should the Byte Dimension been set automatically")]
        public bool AutoByteDimension
        {
            get
            {
                return this._autoByteDimension;
            }
            set
            {
                this._autoByteDimension = value;
                this.SetProcessValues();
            }
        }

        /// <summary>
        /// Byte Dimension, override Automatical Byte Dimension
        /// </summary>
        private FileSize.Dimension _byteDimension = FileSize.Dimension._Automatic_;
        /// <summary>
        /// Get or set the Byte Dimension, override Automatical Byte Dimension
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Byte Dimension")]
        [DefaultValue(true)]
        [Description("Byte Dimension, override Automatical Byte Dimension")]
        public FileSize.Dimension ByteDimension
        {
            get
            {
                return this._byteDimension;
            }
            set
            {
                this._byteDimension = value;
            }
        }

        /// <summary>
        /// Get or set the description text
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Description Text")]
        [DefaultValue("")]
        [Description("Text to show in the Description text area")]
        public string DescriptionText
        {
            get
            {
                return this.txtDescript.Text;
            }
            set
            {
                this.txtDescript.Text = value;
            }
        }

        /// <summary>
        /// Get or set wich element should been grown, if the dimension ComboBox is hidden
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Hide Dimension grow Mode")]
        [DefaultValue(HideDimensionMode.GrowValueTextBox)]
        [Description("Wich element should been grown, if the dimension ComboBox is hidden")]
        public HideDimensionMode HideDimensionGrowMode { get; set; } = ExtProgressBar.HideDimensionMode.GrowValueTextBox;

        /// <summary>
        /// The maximum Value of the progress
        /// </summary>
        private long _maxValue = 0;
        /// <summary>
        /// Get or set the maximum Value of the progress. NULL will be converted to -1
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Maximum Value")]
        [DefaultValue(0)]
        [Description("Maximum Value of the progress. NULL will be converted to -1")]
        public long? MaxValue
        {
            get
            {
                return this._maxValue;
            }
            set
            {
                this._maxValue = (long)(value == null ? -1 : value);
                this.SetProcessValues();
            }
        }

        /// <summary>
        /// Get or set the style that the ProgressBar uses to indicate the progress.
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("ProgressBar Style")]
        [DefaultValue(ProgressBarStyle.Blocks)]
        [Description("Specifies the style that the ProgressBar uses to indicate the progress.")]
        public ProgressBarStyle Style
        {
            get
            {
                return this.pbaProgress.Style;
            }
            set
            {
                this.pbaProgress.Style = value;
            }
        }

        /// <summary>
        ///  Defines if the ComboBox for FileSizes should been shown
        /// </summary>
        private bool _showDescriptionText = true;
        /// <summary>
        /// Get or set if the ComboBox for FileSizes should been shown
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Show Description Text")]
        [DefaultValue(true)]
        [Description("Defines if the Description Text should been shown")]
        public bool ShowDescriptionText
        {
            get
            {
                return this._showDescriptionText;
            }
            set
            {
                this._showDescriptionText = value;
                this.txtDescript.Visible = value;

                if (value)
                {
                    this.cboByteDime.Location = new Point(this.cboByteDime.Location.X, this._cboByteDimeCalLoc.Y + this._desOffsetY);
                    this.pbaProgress.Location = new Point(this.pbaProgress.Location.X, this._pbaProgressCalLoc.Y + this._desOffsetY);
                    this.txtBytesNum.Location = new Point(this.txtBytesNum.Location.X, this._txtBytesNumCalLoc.Y + this._desOffsetY);
                    this.txtBytesPer.Location = new Point(this.txtBytesPer.Location.X, this._txtBytesPerCalLoc.Y + this._desOffsetY);
                }
                else
                {
                    this.cboByteDime.Location = new Point(this.cboByteDime.Location.X, this._cboByteDimeCalLoc.Y - this._desOffsetY);
                    this.pbaProgress.Location = new Point(this.pbaProgress.Location.X, this._pbaProgressCalLoc.Y - this._desOffsetY);
                    this.txtBytesNum.Location = new Point(this.txtBytesNum.Location.X, this._txtBytesNumCalLoc.Y - this._desOffsetY);
                    this.txtBytesPer.Location = new Point(this.txtBytesPer.Location.X, this._txtBytesPerCalLoc.Y - this._desOffsetY);
                }

                this._cboByteDimeCalLoc.Y = this.cboByteDime.Location.Y;
                this._pbaProgressCalLoc.Y = this.pbaProgress.Location.Y;
                this._txtBytesNumCalLoc.Y = this.txtBytesNum.Location.Y;
                this._txtBytesPerCalLoc.Y = this.txtBytesPer.Location.Y;

                this.Height = this.pbaProgress.Location.Y + this.pbaProgress.Height;
            }
        }

        /// <summary>
        ///  Defines if the ComboBox for FileSizes should been shown
        /// </summary>
        private bool _showDimensionComboBox = true;
        /// <summary>
        /// Get or set if the ComboBox for FileSizes should been shown
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Show Dimension ComboBox")]
        [DefaultValue(true)]
        [Description("Defines if the ComboBox for FileSizes should been shown")]
        public bool ShowDimensionComboBox
        {
            get
            {
                return this._showDimensionComboBox;
            }
            set
            {
                this._showDimensionComboBox = value;
                this.cboByteDime.Visible = value;

                switch (this.HideDimensionGrowMode)
                {
                    case HideDimensionMode.GrowProgressBar:
                        if (value)
                        {
                            this.pbaProgress.Size = new Size(this._pbaProgressCalWidth - this._dimOffsetX, this.pbaProgress.Size.Height);
                            this.txtBytesNum.Location = new Point(this._txtBytesNumCalLoc.X - this._dimOffsetX, this.txtBytesNum.Location.Y);
                            this.txtBytesPer.Location = new Point(this._txtBytesPerCalLoc.X - this._dimOffsetX, this.txtBytesPer.Location.Y);
                        }
                        else
                        {
                            this.pbaProgress.Size = new Size(this._pbaProgressCalWidth + this._dimOffsetX, this.pbaProgress.Size.Height);
                            this.txtBytesNum.Location = new Point(this._txtBytesNumCalLoc.X + this._dimOffsetX, this.txtBytesNum.Location.Y);
                            this.txtBytesPer.Location = new Point(this._txtBytesPerCalLoc.X + this._dimOffsetX, this.txtBytesPer.Location.Y);
                        }
                        break;
                    case HideDimensionMode.GrowValueTextBox:
                        if (value)
                        {
                            this.txtBytesNum.Size = new Size(this._txtBytesNumCalWidth - this._dimOffsetX, this.txtBytesNum.Size.Height);
                        }
                        else
                        {
                            this.txtBytesNum.Size = new Size(this._txtBytesNumCalWidth + this._dimOffsetX, this.txtBytesNum.Size.Height);
                        }
                        break;
                    default:
                        throw new ArgumentException();
                }
                this._pbaProgressCalWidth = this.pbaProgress.Size.Width;
                this._txtBytesNumCalLoc.X = this.txtBytesNum.Location.X;
                this._txtBytesNumCalWidth = this.txtBytesNum.Size.Width;
                this._txtBytesPerCalLoc.X = this.txtBytesPer.Location.X;
            }
        }

        /// <summary>
        /// The actual Value of the progress. Set to -1 to blank percentage and numeric TextBox.
        /// </summary>
        private long _value = -1;
        /// <summary>
        /// Get or set the actual Value of the progress. Set to -1 to blank percentage and numeric TextBox. NULL will be converted to -1.
        /// </summary>
        [Category("ProgressBar Extension")]
        [DisplayName("Value")]
        [DefaultValue(-1)]
        [Description("Actual Value of the progress. Set to -1 to blank percentage and numeric TextBox. NULL will be converted to -1")]
        public long? Value
        {
            get
            {
                return this._value;
            }
            set
            {
                this._value = (long)(value == null ? -1 : value);
                this.SetProcessValues();
            }
        }
        #endregion

        #region Methodes
        /// <summary>
        /// Initial a new ProgressbarExt
        /// </summary>
        public ExtProgressBar()
        {
            InitializeComponent();

            MessageBox.Show("IW:" + this.Width.ToString());

            //Initial Combobox
            FileSize.SetDimensionlistToComboBox(this.cboByteDime, FileSize.ByteBase.IEC, FileSize.ByteBase.SI, true, true);
            Tools.ComboBox.AutoDropDownWidth(this.cboByteDime);
            Tools.ComboBox.SetToFirstIndex(this.cboByteDime);

            //Initial with and position calculations
            this._desOffsetY = this.txtDescript.Height + this.txtDescript.Margin.Bottom + this.txtDescript.Margin.Top;
            this._dimOffsetX = this.cboByteDime.Width + this.cboByteDime.Margin.Left + this.txtBytesNum.Margin.Right;

            this._cboByteDimeCalLoc.X = this.cboByteDime.Location.X + this._dimOffsetX;
            this._cboByteDimeCalLoc.Y = this.cboByteDime.Location.Y;// + this._desOffsetY;

            this._pbaProgressCalLoc.X = this.pbaProgress.Location.X + this._dimOffsetX;
            this._pbaProgressCalLoc.Y = this.pbaProgress.Location.Y;// + this._desOffsetY;
            this._pbaProgressCalWidth = this.pbaProgress.Size.Width + this._dimOffsetX;

            this._txtBytesNumCalLoc.X = this.txtBytesNum.Location.X + this._dimOffsetX;
            this._txtBytesNumCalLoc.Y = this.txtBytesNum.Location.Y;// + this._desOffsetY;
            this._txtBytesNumCalWidth = this.txtBytesNum.Size.Width + this._dimOffsetX;

            this._txtBytesPerCalLoc.X = this.txtBytesPer.Location.X + this._dimOffsetX;
            this._txtBytesPerCalLoc.Y = this.txtBytesPer.Location.Y;// + this._desOffsetY;
        }

        /// <summary>
        /// Clear the ProgressBar (to 0 and BlockStyle) and all TextBoxes
        /// </summary>
        public void Clear()
        {
            this.Clear(true);
        }
        /// <summary>
        /// Clear the ProgressBar (to 0 and if wanted to BlockStyle) and all TextBoxes
        /// </summary>
        /// <param name="setProgressBarStyleToBlocks">Shold the ProgressBarStyle set to Blocks</param>
        public void Clear(bool setProgressBarStyleToBlocks)
        {
            if (setProgressBarStyleToBlocks) ProgressBarInv.Style(this.pbaProgress, ProgressBarStyle.Blocks);
            ProgressBarInv.Value(this.pbaProgress, 0);
            TextBoxInv.Text(this.txtBytesNum, "");
            TextBoxInv.Text(this.txtBytesPer, "");
            TextBoxInv.Text(this.txtDescript, "");
        }

        /// <summary>
        /// Set the value for the ProgressBar and the TextBoxes
        /// </summary>
        private void SetProcessValues()
        {
            decimal ActValue;
            decimal MaxValue = this._maxValue;
            uint Dimension;
            
            if (this._autoByteDimension)
            {

                if (this._maxValue > 0)
                {
                    Dimension = FileSize.GetHighestDimension(this._maxValue, this.AutoByteBase, FileSize.Dimension._Automatic_);

                    ActValue = FileSize.ConvertNum(this._value, DECIMAL_DIGITS, this.AutoByteBase, (FileSize.Dimension)Dimension);
                    MaxValue = FileSize.ConvertNum(this._maxValue, DECIMAL_DIGITS, this.AutoByteBase, (FileSize.Dimension)Dimension);
                }
                else
                {
                    Dimension = FileSize.GetHighestDimension(this._value, this.AutoByteBase, FileSize.Dimension._Automatic_);
                    ActValue = FileSize.ConvertNum(this._value, DECIMAL_DIGITS, this.AutoByteBase, (FileSize.Dimension)Dimension);
                }
                this.ByteDimension = (FileSize.Dimension)Dimension;

                this._suppressControleEvents = true;
                ComboBoxInv.SelectedIndex(this.cboByteDime, (int)Dimension + (this.AutoByteBase == FileSize.ByteBase.IEC ? 0 : FileSize.UnitPrefix_IEC.Length));
                //TODO: REMOVE this.cboByteDime.SelectedIndex = (int)Dimension + (this.AutoByteBase == FileSize.ByteBase.IEC ? 0 : FileSize.UnitPrefix_IEC.Length);
                this._suppressControleEvents = false;
            }
            else
            {
                Dimension = (uint)this.cboByteDime.SelectedIndex;
                Dimension -= (uint)(Dimension >= FileSize.UnitPrefix_IEC.Length ? FileSize.UnitPrefix_IEC.Length : 0);

                FileSize.ByteBase ByteBase = this.cboByteDime.SelectedIndex >= FileSize.UnitPrefix_IEC.Length ? FileSize.ByteBase.SI : FileSize.ByteBase.IEC;

                ActValue = FileSize.ConvertNum(this._value, DECIMAL_DIGITS, ByteBase, (FileSize.Dimension)Dimension);
                if (this._maxValue > 0) MaxValue = FileSize.ConvertNum(this._maxValue, DECIMAL_DIGITS, ByteBase, (FileSize.Dimension)Dimension);
            }

            if (this._maxValue > 0)
            {
                this._percentageProgress = (int)Matehmatics.UpLimit(Matehmatics.Percentages(this._value, this._maxValue), 100);
                ProgressBarInv.Value(this.pbaProgress, this._percentageProgress);
                TextBoxInv.Text(this.txtBytesPer, this._value == -1 ? "" : string.Format(FORMAT_PERCENTAGE, this._percentageProgress));
                TextBoxInv.Text(this.txtBytesNum, this._value == -1 ? "" : string.Format(FORMAT_ACTUAL_MAX_VALUE, new object[] { string.Format(FORMAT_VALUE, ActValue), string.Format(FORMAT_VALUE, MaxValue) }));
                //this.pbaProgress.Value = this._percentageProgress;
                //this.txtBytesPer.Text = this._value == -1 ? "" : string.Format(FORMAT_PERCENTAGE, this._percentageProgress);
                //this.txtBytesNum.Text = this._value == -1 ? "" : string.Format(FORMAT_ACTUAL_MAX_VALUE, new object[] { string.Format(FORMAT_VALUE, ActValue), string.Format(FORMAT_VALUE, MaxValue) });
            }
            else
            {
                this._percentageProgress = 0;
                ProgressBarInv.Value(this.pbaProgress, 0);
                TextBoxInv.Text(this.txtBytesPer, "");
                TextBoxInv.Text(this.txtBytesNum, this._value == -1 ? "" : string.Format(FORMAT_VALUE, ActValue));
                //this.pbaProgress.Value = 0;
                //this.txtBytesPer.Text = "";
                //this.txtBytesNum.Text = this._value == -1 ? "" : string.Format(FORMAT_VALUE, ActValue);
            }
        }

        #region Controle events
        private void cboByteDimension_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this._suppressControleEvents) return;
            //TODO: REMOVE this._autoByteDimension = false;
            this.SetProcessValues();
        }

        private void ProgressbarEx_Resize(object sender, EventArgs e)
        {
            MessageBox.Show("nw:" + this.Width.ToString());

            this._cboByteDimeCalLoc.X = this.cboByteDime.Location.X;
            this._cboByteDimeCalLoc.Y = this.cboByteDime.Location.Y;

            this._pbaProgressCalLoc.X = this.pbaProgress.Location.X;
            this._pbaProgressCalLoc.Y = this.pbaProgress.Location.Y;
            this._pbaProgressCalWidth = this.pbaProgress.Size.Width;

            this._txtBytesNumCalLoc.X = this.txtBytesNum.Location.X;
            this._txtBytesNumCalLoc.Y = this.txtBytesNum.Location.Y;
            this._txtBytesNumCalWidth = this.txtBytesNum.Size.Width;

            this._txtBytesPerCalLoc.X = this.txtBytesPer.Location.X;
            this._txtBytesPerCalLoc.Y = this.txtBytesPer.Location.Y;

            this.Height = this.pbaProgress.Location.Y + this.pbaProgress.Height;
        }
        #endregion
        #endregion
    }
}